import time

time.sleep(1)

print("1")
