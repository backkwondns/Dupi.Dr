const proxy = require('http-proxy-middleware');

module.exports = function(app) {
	app.use('/api',
		proxy({
			target: `http://203.249.90.7:31000`,
			changeOrigin: true,
		})
	)
};
